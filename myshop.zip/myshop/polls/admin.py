from django.contrib import admin
from.models.samplepdt import Sample
from.models.customer import Customer
from.models.categorys import Categorys
from.models.products import Prod
from.models.product import Product
from.models.category import Category
from.models.orders import Orders
# Register your models here.


class AdminProduct(admin.ModelAdmin):
    list_display = ['name', 'price', 'discount', 'category']


class AdminCategory(admin.ModelAdmin):
    list_display = ['name']


class AdminCustomer(admin.ModelAdmin):
    list_display = ['name', 'email', 'mobnumber', 'state', 'city', 'zip']


class AdminOrders(admin.ModelAdmin):
    list_display = ['customer', 'product', 'quantity', 'price', 'date', 'name', 'address', 'city', 'state', 'zip', 'mobnumber', 'email', 'status']


admin.site.register(Product, AdminProduct)
admin.site.register(Category, AdminCategory)
admin.site.register(Customer, AdminCustomer)
admin.site.register(Orders, AdminOrders)
admin.site.register(Sample)
admin.site.register(Categorys)
admin.site.register(Prod)
