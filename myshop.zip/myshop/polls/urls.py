from django.urls import path

from . import views
from .views import Basket, Signup, Login, Index, Cart, logout, empty, Basket,emptycart, success, Check, Order
from.middleware.auth import auth_middleware
urlpatterns = [
    path('', views.index, name='main'),
    path('home', Index.as_view(), name='home'),
    path('/', Index.as_view()),
    path('signup', Signup.as_view()),
    path('login', Login.as_view()),
    path('logout', logout, name='logout'),
    path('cart/', auth_middleware(Cart.as_view()), name='cart'),
    path('logout', views.logout, name='logout'),
    path('empty', views.empty),
    path('check/', Check.as_view(), name='check'),
    path('emptycart',views.emptycart),
    path('basket', Basket.as_view()),
    path('order', auth_middleware(Order.as_view()), name='order'),
    path('success', success, name='success'),


    #path('cart',views.cart)


   
]