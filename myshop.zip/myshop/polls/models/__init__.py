from.samplepdt import Sample
from.customer import Customer
from.product import Product
from.category import Category
from.products import Prod
from.categorys import Categorys
from.orders import Orders
from.payment import Payment