from django.db import models


class Categorys(models.Model):
    name = models.CharField(max_length=50)
