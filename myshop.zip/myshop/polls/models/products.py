from django.db import models
from.categorys import Categorys


class Prod(models.Model):
    title = models.CharField(max_length=50)
    rate = models.IntegerField(default=0)
    categorys = models.ForeignKey(Categorys, on_delete=models.CASCADE, default=1)
    percent = models.IntegerField(default=0)
    image = models.ImageField(upload_to='sample/')

    @staticmethod
    def get_prods_by_id(ides):
        return Prod.objects.filter(id__in=ides)

    @staticmethod
    def get_all_prods():
        return Prod.objects.all()

