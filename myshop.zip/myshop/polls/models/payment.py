from django.db import models
from.orders import Orders


class Payment(models.Model):
    orders = models.ForeignKey(Orders, on_delete=models.CASCADE)
    date = models.DateTimeField(null=False, auto_now_add=True)
    payment_status = models.CharField(max_length=30, default='FAILED')
    payment_id = models.CharField(max_length=60)
    payment_request = models.CharField(max_length=60, unique=True, null=False)