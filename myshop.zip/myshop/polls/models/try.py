def index(request):
    prods = Prod.get_all_prods()
    info = {}
    info['prods'] = prods
    for i in prods:
        i.afterpercent = i.rate - (i.rate * i.percent / 100)
        print(i.afterpercent)
        i.afterpercent = floor(i.afterpercent)
    return render(request, 'index.html', info)