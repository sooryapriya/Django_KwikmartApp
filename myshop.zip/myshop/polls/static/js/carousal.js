$('.carousel').carousel({
  interval: 6000,
  pause: "false"
});
sample = request.POST.get('sample')
        removebasket = request.POST.get('removebasket')
        basket = request.session.get('basket')
        if basket:
            amt = basket.get(basket)
            if amt:
                if removebasket:
                    if amt <= 1:
                        basket.pop(sample)
                    else:
                        basket[sample] = amt - 1
                else:
                    basket[sample] = amt + 1
            else:
                basket[sample] = 1
        else:
            basket = {}
            basket[sample] = 1