from django import template
register = template.Library()


@register.filter(name='is_in_basket')
def is_in_basket(sample, basket):
    keys = basket.keys()
    print(sample, basket)
    for ides in keys:
        print(ides, sample.id)
        print(type(ides), type(sample.id))
        if int_or_0(ides) == int(sample.id):
            return True
    return False;


def int_or_0(value):
    try:
        return int(value)
    except:
        return 0


@register.filter(name='basket_quantity')
def basket_quantity(sample, basket):
    keys = basket.keys()
    for ids in keys:
        if int(ids) == sample.id:
            return basket.get(ids)
    return 0;




