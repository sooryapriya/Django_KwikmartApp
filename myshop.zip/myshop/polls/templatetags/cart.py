from django import template
from math import floor
register = template.Library()


@register.filter(name='is_in_cart')
def is_in_cart(product, cart):
    keys = cart.keys()
    print(product, cart)
    for ids in keys:
        print(ids, product.id)
        int(ids)
        print(type(ids), type(product.id))
        if (int_or_0(ids))== int(product.id):
            return True
    return False;


def int_or_0(value):
    try:
        return int(value)
    except:
        return 0


@register.filter(name='cart_quantity')
def cart_quantity(product, cart):
    keys = cart.keys()
    for ids in keys:
        if int(ids) == int(product.id):
            return cart.get(ids)
    return 0;


@register.filter(name='price_discount')
def price_discount(product, cart):
    pdiscount = product.price - (product.price * product.discount/100)
    pdiscount = floor(pdiscount)
    return pdiscount


@register.filter(name='price_total')
def price_total(product, cart):
    pdiscount = product.price - (product.price * product.discount / 100)
    pdiscount = floor(pdiscount)
    return pdiscount * cart_quantity(product, cart)


@register.filter(name='total_pay')
def total_pay(products, cart):
    total = 0;
    for p in products:
        total += price_total(p, cart)
    return total



















